package com.securityprac.dbspringsecurityDB.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.securityprac.dbspringsecurityDB.dto.AccountRequestDTO;
import com.securityprac.dbspringsecurityDB.dto.AccountResponseDTO;
import com.securityprac.dbspringsecurityDB.service.AccountService;

@RestController
public class AccountController {

	private  AccountService service;
	
	public AccountController(AccountService service)
		this.service = service;
	}



	@PostMapping("/create")
	public AccountResponseDTO create(@RequestBody AccountRequestDTO dto) {
		return service.createAccount(dto);
	}
	
	
	
	
	
